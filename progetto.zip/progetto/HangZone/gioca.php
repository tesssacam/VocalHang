<?php
session_start();

if (!isset($_SESSION['utente'])) {
    header("Location: login.html");
    exit;
}

$ruolo = $_SESSION['utente']['ruolo'];
$username = $_SESSION['utente']['username'];
?>

<!DOCTYPE html>
<html lang="it">
<head>
<title>VocalHang</title> 
<meta charset="UTF-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
@font-face {
  font-family: 'SanFrancisco';
  src: url('font/1601919916wpdm_San-Francisco/San Francisco/otf/SFNSDisplay-Medium.otf') format('opentype');
}
body {
  font-family: 'SanFrancisco', sans-serif;
  display: flex; 
  flex-direction: column; 
  align-items: center; 
  padding: 20px; 
  background-color: #fafafa;
}
h1 { margin-bottom: 10px; }
.gioco { width: 600px; max-width: 95%; padding: 16px; border-radius: 10px; background-color: #fafafa; }
.parola { font-size: 32px; letter-spacing: 6px; text-align: center; margin: 16px 0; }
.info { display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; }
.messaggio { min-height: 28px; text-align:center; margin-bottom:10px; }
button { padding:8px 12px; border-radius:8px; border: none; cursor:pointer; background-color: #504d4d; color: white; }
button:hover { background-color: #504d4d; }
.cuori-container { text-align: center; margin-bottom: 12px; }
.cuore { width: 58px; height: 58px; display: inline-block; margin: 0 4px; background-size: contain; background-repeat: no-repeat; image-rendering: pixelated; background-image: url('./img/cuore_pieno.png'); }
.cuore.vuoto { background-image: url('./img/cuore_vuoto.png'); }
</style>
</head>
<body>
<h1>VOCALHANG</h1>

<?php if ($ruolo === "admin") { ?>
    <button onclick="location.href='impostazioni.html'" 
            style="margin-bottom:15px; padding:10px; background:#222; color:white; border-radius:8px;">
        SETTINGS
    </button>
<?php } ?>


<div>
  <label for="lingua">Scegli lingua:</label>
  <select id="lingua">
    <option value="it">Italiano</option>
    <option value="en">English</option>
    <option value="fr">Français</option>
    <option value="es">Español</option>
  </select>
</div>

<div class="gioco" id="contenitoreGioco"> 
  <div class="info">
    <div><span class="vita" id="viteRimanenti"></span></div> 
    <div><button id="btnRicomincia">nuova parola</button></div>
  </div>
  <div class="cuori-container" id="cuoriContainer"></div>
  <div class="parola" id="displayParola">_ _ _ _ _</div> 
  <div class="messaggio" id="messaggio"></div> 
</div>

<script>
let paroleData = null, parolaCorrente = "", lettereScoperte = [], vite = 0;
const displayParola = document.getElementById('displayParola');
const viteRimanenti = document.getElementById('viteRimanenti');
const messaggio = document.getElementById('messaggio');
const btnRicomincia = document.getElementById('btnRicomincia');
const cuoriContainer = document.getElementById('cuoriContainer');

const selectLingua = document.getElementById('lingua');

async function inizializzaGioco(){
  try{
    const risposta = await fetch('./file/parole.json'); 
    paroleData = await risposta.json();
  } catch(err){ 
    console.error(err);
    paroleData = { viteIniziali:6, it:['prova','fallback'], en:['test','fallback'], fr:['test','fallback'], es:['prueba','fallback'] };
  }
  nuovaPartita();
}

function nuovaPartita(){
  const listaParole = paroleData[selectLingua.value];
  parolaCorrente = listaParole[Math.floor(Math.random() * listaParole.length)].toLowerCase();
  lettereScoperte = Array.from(parolaCorrente).map(ch => (ch === ' '? true : false));
  vite = Number(paroleData.viteIniziali) || 6;
  aggiornaDisplay();
  aggiornaVite();
  aggiornaCuori();
  messaggio.textContent = '';
}

function aggiornaDisplay(){ 
  displayParola.textContent = Array.from(parolaCorrente).map((ch,i)=>lettereScoperte[i]?ch.toUpperCase():ch===' '?' ':'_').join(' '); 
}

function aggiornaVite(){ viteRimanenti.textContent = vite; }

function aggiornaCuori(){
  cuoriContainer.innerHTML = '';
  const viteTotali = Number(paroleData.viteIniziali) || 6;
  for(let i=0;i<viteTotali;i++){
    const cuore = document.createElement('span');
    cuore.classList.add('cuore');
    if(i >= vite) cuore.classList.add('vuoto');
    cuoriContainer.appendChild(cuore);
  }
}

function tentativoLettera(lettera){
  if(vite <= 0) return;
  let trovata = false;
  for(let i=0;i<parolaCorrente.length;i++){
    if(parolaCorrente[i] === lettera){ lettereScoperte[i] = true; trovata = true; }
  }
  if(!trovata){ vite--; messaggio.textContent=`lettera "${lettera.toUpperCase()}" sbagliata`; }
  else{ messaggio.textContent=`✅ lettera "${lettera.toUpperCase()}" trovata`; }
  aggiornaDisplay(); aggiornaVite(); aggiornaCuori(); controllaEsito();
}

function controllaEsito(){
  if(lettereScoperte.every(v => v === true)){
    messaggio.textContent='hai vinto!';
    vite = 0; aggiornaCuori(); 
    return;
  }
  if(vite <= 0){
    messaggio.textContent=`💀 Hai perso! La parola era: ${parolaCorrente.toUpperCase()}`;
    lettereScoperte = Array.from(parolaCorrente).map(()=>true);
    aggiornaDisplay(); aggiornaCuori();
  }
}

document.addEventListener('keydown',(e)=>{
  const lettera = e.key.toLowerCase();
  if(lettera >= 'a' && lettera <= 'z') tentativoLettera(lettera);
});

btnRicomincia.addEventListener('click', ()=>nuovaPartita());
document.addEventListener('DOMContentLoaded', ()=>inizializzaGioco());
</script>
</body>
</html>
