<?php
$host = "localhost";  
$user = "root";       
$pass = "";           
$db   = "db_cam";  

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("errore connessione: " . $conn->connect_error);
}

$conn->set_charset("utf8");
?>
