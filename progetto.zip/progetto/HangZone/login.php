<?php
session_start();
include 'connessione.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, ruolo FROM utenti WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $hash, $ruolo);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();

        if (password_verify($password, $hash)) {

         
            $_SESSION['utente'] = [
                "id" => $id,
                "username" => $username,
                "ruolo" => $ruolo,
            ];

            echo "ok";
        } else {
            echo "errore";
        }
    } else {
        echo "errore";
    }
}
?>
