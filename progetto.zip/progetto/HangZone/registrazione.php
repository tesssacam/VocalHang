<?php
include 'connessione.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // cripta la password
    $dataNascita = $_POST['dataNascita'];
    $ruolo =  $_POST['ruolo'];
    $parole_indovinate = '';
    $partite_giocate = 0;
    $lingua = 'it';

    // Controlla se username esiste già
    $stmt = $conn->prepare("SELECT id FROM utenti WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "errore_username"; // già esistente
    } else {
        $stmt = $conn->prepare("INSERT INTO utenti (username, password, dataNascita, ruolo, parole_indovinate, partite_giocate, lingua) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssis", $username, $password, $dataNascita, $ruolo, $parole_indovinate, $partite_giocate, $lingua);
        if($stmt->execute()){
            echo "ok";
        } else {
            echo "errore";
        }
    }
}
?>
