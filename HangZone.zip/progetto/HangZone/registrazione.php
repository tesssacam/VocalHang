<?php
include 'connessione.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $password2 = trim($_POST['password2']);
    $dataNascita = $_POST['dataNascita'];
    $ruolo = trim($_POST['ruolo']);
    $parole_indovinate = '';
    $partite_giocate = 0;
    $lingua = 'it';


    if (!$username || !$password || !$password2 || !$dataNascita || !$ruolo) {
        echo "errore_campi_vuoti";
        exit;
    }

    if ($password !== $password2) {
        echo "errore_password";
        exit;
    }


    $ruoli_validi = ['giocatore', 'admin'];
    if (!in_array($ruolo, $ruoli_validi)) {
        echo "errore_ruolo_non_valido";
        exit;
    }


    $stmt = $conn->prepare("SELECT id FROM utenti WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "username_esistente";
        exit;
    }


    $password_hash = password_hash($password, PASSWORD_DEFAULT);


    $stmt = $conn->prepare("INSERT INTO utenti (username, password, dataNascita, ruolo, parole_indovinate, partite_giocate, lingua) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssis", $username, $password_hash, $dataNascita, $ruolo, $parole_indovinate, $partite_giocate, $lingua);

    if ($stmt->execute()) {
        echo "ok";
    } else {
        echo "errore";
    }

    $stmt->close();
    $conn->close();
}
?>
