<?php
session_start();


if (!isset($_SESSION['utente'])) {
    header("Location: login.html");
    exit;
}


if ($_SESSION['utente']['ruolo'] !== "admin") {
    echo "accesso negato: non hai i permessi per entrare in questa pagina";
    exit;
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
  <title>Gestione</title> 
  <meta charset="UTF-8"> 
  <meta name="description" content="gestione"> 
  <meta name="keywords" content="HTML,CSS"> 
  <meta name="author" content="Tessa Caminada">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="./img/favicon_tessa.png"> 

  <style>

    @font-face {
      font-family: 'SanFrancisco';
      src: url('font/1601919916wpdm_San-Francisco/San Francisco/otf/SFNSDisplay-Medium.otf') format('opentype');
    }

    * {
      margin: 0; 
      padding: 0; 
      box-sizing: border-box; 
      font-family: 'SanFrancisco', sans-serif;
    }


    body {
      background: linear-gradient(145deg, #f3f3f3, #e8e8e8);
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      padding: 25px;
      font-size: 30px;
      color: #222;
    }

    .background {
      position: fixed;
      left: 0; top: 0; width: 100%; height: 100%;
      background: url('img/sfondo_ios.jpg') no-repeat center/cover;
      opacity: 0.15;
      z-index: -2;
    }


    h1 {
      margin-bottom: 25px;
      font-size: 70px;
      font-weight: 700;
      color: #000;
      letter-spacing: 1px;
      text-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }


  #lingua-container {
    margin-bottom: 15px;       
    background: #ffffffaa;
    padding: 8px 12px;         
    border-radius: 12px;       
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    backdrop-filter: blur(6px);
    font-size: 22px;           
  }

  #lingua {
    font-size: 20px;           
    padding: 6px 10px;           
    border-radius: 8px;
    border: 1px solid #ccc;
    outline: none;
    transition: 0.2s;
  }


    #lingua:hover,
    #lingua:focus {
      border-color: #5a5aff;
    }


    .lista-parole {
      width: 90%;
      max-width: 650px;
      padding: 25px;
      background: #ffffffd2;
      border-radius: 25px;
      backdrop-filter: blur(6px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }

    .parola-item {
      display: flex;
      align-items: center;
      background: #fff;
      padding: 12px 18px;
      margin-bottom: 15px;
      border-radius: 20px;
      box-shadow: 0 3px 8px rgba(0,0,0,0.12);
      transition: 0.2s;
    }

    .parola-item:hover {
      transform: scale(1.02);
    }

    .parola-item input {
      flex: 1;
      padding: 10px;
      font-size: 20px;
      border: none;
      background: transparent;
      outline: none;
    }

    .parola-item img {
      width: 28px;
      height: 28px;
      margin-left: 10px;
      cursor: pointer;
      transition: 0.15s;
    }

    .parola-item img:hover {
      transform: scale(1.15);
    }

    .riga-bottoni {
      display: flex;
      gap: 20px;
      justify-content: center;
      margin-top: 25px;
    }

    .button {
      appearance: none;
      background-color: #000;
      color: #fff;
      border: none;
      border-radius: 14px;
      padding: 12px 25px;
      font-size: 27px;
      font-weight: 600;
      cursor: pointer;
      letter-spacing: 0.04cm;
      transition: all 0.25s ease;
      box-shadow: 0 5px 12px rgba(0,0,0,0.2);
    }

    .button:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.25);
    }


    .button.white {
      background: white;
      color: black;
    }

    .button.blue {
      background: rgb(74, 74, 112);
    }
  </style>
</head>

<body>

  <div class="background"></div>

  <h1>Gestione Parole</h1>

  <div id="lingua-container">
    <label for="lingua">Scegli lingua:</label>
    <select id="lingua">
      <option value="it">Italiano</option>
      <option value="en">English</option>
      <option value="fr">Français</option>
      <option value="es">Español</option>
    </select>
  </div>

  <div class="lista-parole" id="lista-parole"></div>

  <div class="riga-bottoni">
    <button class="button white" onclick="location.href='gioca.php'">Indietro</button>
    <button class="button" id="salva-btn">Salva</button>
    <button class="button blue" id="crea-btn">Crea</button>
  </div>


  <script>
    const lista = document.getElementById('lista-parole');
    const selectLingua = document.getElementById('lingua');
    let paroleJSON = {};

    function renderParole() {
      lista.innerHTML = '';
      const lingua = selectLingua.value;
      if (!paroleJSON[lingua]) return;

      paroleJSON[lingua].forEach((parola, index) => {
        const div = document.createElement('div');
        div.className = 'parola-item';

        const input = document.createElement('input');
        input.type = 'text';
        input.value = parola;

        const imgMod = document.createElement('img');
        imgMod.src = 'https://cdn-icons-png.flaticon.com/512/1159/1159633.png';
        imgMod.title = 'Modifica';
        imgMod.onclick = () => input.focus();

        const imgDel = document.createElement('img');
        imgDel.src = 'https://cdn-icons-png.flaticon.com/512/1214/1214428.png';
        imgDel.title = 'Elimina';
        imgDel.onclick = () => {
          paroleJSON[lingua].splice(index, 1);
          renderParole();
        };

        div.appendChild(input);
        div.appendChild(imgMod);
        div.appendChild(imgDel);

        lista.appendChild(div);
      });
    }

    selectLingua.addEventListener('change', renderParole);

    document.getElementById('crea-btn').addEventListener('click', () => {
      const lingua = selectLingua.value;
      paroleJSON[lingua].push('');
      renderParole();
      const inputs = lista.querySelectorAll('input');
      inputs[inputs.length - 1].focus();
    });

    document.getElementById('salva-btn').addEventListener('click', () => {
      const lingua = selectLingua.value;
      const inputs = lista.querySelectorAll('input');
      paroleJSON[lingua] = Array.from(inputs)
        .map(i => i.value.trim())
        .filter(i => i);
      alert('il file JSON è stato aggiornato');
      console.log(paroleJSON);
    });

    fetch('./file/parole.json')
      .then(response => response.json())
      .then(data => {
        paroleJSON = data;
        renderParole();
      });
  </script>

</body>
</html>
