<?php
session_start();


if (!isset($_SESSION['utente'])) {
    header("Location: login.html");
    exit;
}

$ruolo = $_SESSION['utente']['ruolo'];
$username = $_SESSION['utente']['username'];
?>

<!DOCTYPE html>
<html lang="it">
<head>
  <title>Gioca</title> 
	<meta charset="UTF-8"> 
	<meta name="description" content="gioca"> 
	<meta name="keywords" content="HTML,CSS"> 
	<meta name="author" content="Tessa Caminada">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="./img/favicon_tessa.png"> 

<style>
@font-face {
  font-family: 'SanFrancisco';
  src: url('font/1601919916wpdm_San-Francisco/San Francisco/otf/SFNSDisplay-Medium.otf') format('opentype');
}


body {
  font-family: 'SanFrancisco', sans-serif;
  background-color: #fafafa;
  margin: 0;
  padding: 25px;
  display: flex;
  flex-direction: column;
  align-items: center;
}


.navbar {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 18px 30px;
  background-color: #000000;
  color: white;
  font-size: 30px;
  border-radius: 14px;
  box-sizing: border-box;
}

.navbar .logo {
  font-weight: 700;
  font-size: 38px;
}

.navbar .nav-destra {
  display: flex;
  align-items: center;
  gap: 20px;
}

.navbar .nav-button {
  background-color: #ffffff;
  color: #000;
  font-size: 25px;
  padding: 10px 20px;
  border-radius: 12px;
  border: none;
  cursor: pointer;
  transition: 0.2s;
  font-weight: 600;
}

.navbar .nav-button:hover {
  transform: scale(1.06);
  box-shadow: 0 4px 10px rgba(0,0,0,0.25);
}


.main-wrapper {
  margin-top: 110px;    
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}


.scelta-lingua {
  font-size: 30px;
  margin-bottom: 45px;
}

.scelta-lingua select {
  width: 130px;
  height: 40px;
  font-size: 20px;
  border-radius: 12px;
}


.gioco {
  width: 600px;
  max-width: 95%;
  padding: 35px;
  border-radius: 20px;
  background-color: #ffffff;
  box-shadow: 0 5px 20px rgba(0,0,0,0.10);
}

.parola {
  font-size: 50px;
  letter-spacing: 14px;
  text-align: center;
  margin: 35px 0;
}

.info {
  display:flex;
  justify-content:space-between;
  align-items:center;
  font-size: 45px;
}

.messaggio {
  font-size: 38px;
  min-height: 40px;
  text-align:center;
  margin-top: 30px;
}


.cuori-container { 
  text-align: center;
  margin-bottom: 30px; 
}

.cuore {
  width: 80px;
  height: 80px;
  display: inline-block;
  margin: 0 6px;
  background-size: contain;
  background-repeat: no-repeat;
  image-rendering: pixelated;
  background-image: url('./img/cuore_pieno.png');
}

.cuore.vuoto {
  background-image: url('./img/cuore_vuoto.png');
}


.button {
  appearance: none;
  background-color: #000000;
  border: 2px solid #1A1A1A;
  border-radius: 20px;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-size: 25px;
  font-weight: 600;
  margin-top: 40px;
  padding: 22px 35px;
  transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
}

.button:hover {
  box-shadow: rgba(0, 0, 0, 0.25) 0 8px 15px;
  transform: translateY(-2px);
}

.button:active {
  box-shadow: none;
  transform: translateY(0);
}
</style>
</head>
<body>


<div class="navbar">
  <div class="logo">VocalHang</div>

  <div class="nav-destra">
    <button class="nav-button" id="btnGestione">
      gestione parole
    </button>
  </div>
</div>


<div class="main-wrapper">

  <div class="scelta-lingua">
    <label for="lingua">Scegli lingua:</label>
    <select id="lingua">
      <option value="it">Italiano</option>
      <option value="en">English</option>
      <option value="fr">Français</option>
      <option value="es">Español</option>
    </select>
  </div>

  <div class="gioco" id="contenitoreGioco"> 
    <div class="info" style="color:white">
      <div>
        <span class="vita" id="viteRimanenti" style="color:white"></span>
      </div>
    </div>

    <div class="cuori-container" id="cuoriContainer"></div>
    <div class="parola" id="displayParola">_ _ _ _ _</div> 
    <div class="messaggio" id="messaggio"></div> 
  </div>

  <button class="button" id="btnRicomincia">nuova parola</button>

</div> 

<script>
const ruoloUtente = "<?php echo $ruolo; ?>";
const btnGestione = document.getElementById('btnGestione');

btnGestione.addEventListener('click', () => {
    if(ruoloUtente === "admin"){
        window.location.href = 'gestione.php';
    } else {
        window.location.href = 'errore.html';
    }
});


let paroleData = null, parolaCorrente = "", lettereScoperte = [], vite = 0;
const displayParola = document.getElementById('displayParola');
const viteRimanenti = document.getElementById('viteRimanenti');
const messaggio = document.getElementById('messaggio');
const btnRicomincia = document.getElementById('btnRicomincia');
const cuoriContainer = document.getElementById('cuoriContainer');
const selectLingua = document.getElementById('lingua');

async function inizializzaGioco(){
  try{
    const risposta = await fetch('./file/parole.json'); 
    paroleData = await risposta.json();
  } catch(err){ 
    console.error(err);
    paroleData = { viteIniziali:6, it:['prova','fallback'], en:['test','fallback'], fr:['test','fallback'], es:['prueba','fallback'] };
  }
  nuovaPartita();
}

function nuovaPartita(){
  const listaParole = paroleData[selectLingua.value];
  parolaCorrente = listaParole[Math.floor(Math.random() * listaParole.length)].toLowerCase();
  lettereScoperte = Array.from(parolaCorrente).map(ch => (ch === ' '? true : false));
  vite = Number(paroleData.viteIniziali) || 6;
  aggiornaDisplay();
  aggiornaVite();
  aggiornaCuori();
  messaggio.textContent = '';
}

function aggiornaDisplay(){ 
  displayParola.textContent = Array.from(parolaCorrente)
    .map((ch,i)=>lettereScoperte[i]?ch.toUpperCase():ch===' '?' ':'_').join(' '); 
}

function aggiornaVite(){ viteRimanenti.textContent = vite; }

function aggiornaCuori(){
  cuoriContainer.innerHTML = '';
  const viteTotali = Number(paroleData.viteIniziali) || 6;
  for(let i=0;i<viteTotali;i++){
    const cuore = document.createElement('span');
    cuore.classList.add('cuore');
    if(i >= vite) cuore.classList.add('vuoto');
    cuoriContainer.appendChild(cuore);
  }
}

function tentativoLettera(lettera){
  if(vite <= 0) return;
  let trovata = false;
  for(let i=0;i<parolaCorrente.length;i++){
    if(parolaCorrente[i] === lettera){ lettereScoperte[i] = true; trovata = true; }
  }
  if(!trovata){ vite--; messaggio.textContent=`lettera "${lettera.toUpperCase()}" sbagliata`; }
  else{ messaggio.textContent=`lettera "${lettera.toUpperCase()}" trovata`; }
  aggiornaDisplay(); aggiornaVite(); aggiornaCuori(); controllaEsito();
}

function controllaEsito(){
  if(lettereScoperte.every(v => v === true)){
    messaggio.textContent='hai vinto!';
    vite = 0; aggiornaCuori(); 
    return;
  }
  if(vite <= 0){
    messaggio.textContent=`hai perso! \n la parola era: ${parolaCorrente.toUpperCase()}`;
    lettereScoperte = Array.from(parolaCorrente).map(()=>true);
    aggiornaDisplay(); aggiornaCuori();
  }
}

document.addEventListener('keydown',(e)=>{
  const lettera = e.key.toLowerCase();
  if(lettera >= 'a' && lettera <= 'z') tentativoLettera(lettera);
});

btnRicomincia.addEventListener('click', ()=>nuovaPartita());
document.addEventListener('DOMContentLoaded', ()=>inizializzaGioco());
</script>

</body>
</html>
